package com.niit;

import java.util.Scanner;

public class MyMathBuilder {

	static void divisor(int a, int b) 
	{ 
	int cout=1,i;
	  
	 
	    for (i = 1; i <= Math.min(a, b); i++) 
	  
	    {
	        if (a % i == 0 && b % i == 0) 
	        {
	           System.out.println("Common divisors are "+i);
	        }
	        cout++;
	    }
	    if(cout>=2)
	    {
	    	for(int r=2;r<=i;r++)
	    	{
	    		for(int c=0;c<i;c++)
	    		{
	    			System.out.print("*");
	    		}
	    		System.out.println("\n");
	    	}
	    }
	    else
	    {
	    	for(i=0;i<(a+b)/2;i++)
	    	{
	    		System.out.println("*");
	    	}
	    }
	    
	} 
	
	 
	  
	  public static void main(String[] args) {

			Scanner sc = new Scanner(System.in);
			int num1, num2;
					
			System.out.println("Enter the  First Number");
			num1 = sc.nextInt();
			System.out.println("Enter the  second Number");
			num2 = sc.nextInt();

			MyMathBuilder m=new MyMathBuilder();
			m.divisor(num1, num2);
	    
		}
	  

}
